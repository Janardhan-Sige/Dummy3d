# Janardhan — GCP Data Engineer 3D Portfolio

Responsive dark-luxury portfolio starter using Next.js 14 App Router, TypeScript, Tailwind CSS, Framer Motion, React Three Fiber, Drei, GSAP ScrollTrigger and Zustand. The 3D scene uses primitive geometry only.

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000.

## Before deploying
1. Replace `your.email@example.com` in `components/Portfolio.tsx` with your email.
2. Replace generic LinkedIn and GitHub URLs with your profiles.
3. Review project and experience copy; project cards are example architecture case studies, not claims of verified production deployments.
4. Run `npm run build` to verify a production build.

## Vercel
Push this folder to a Git repository, import it in Vercel and deploy with the Next.js preset. No environment variables are required.

## Implementation notes
- Fixed React Three Fiber canvas with glowing cylinder, five flowing data paths, orbiting cubes, dust particles and floating orbs.
- GSAP ScrollTrigger updates Zustand scene progress as the page scrolls.
- Project cards tilt with pointer movement; responsive layouts are provided for mobile.
- Sections are not hard-pinned by default to preserve mobile usability. Selective desktop pinning can be added after device testing.
