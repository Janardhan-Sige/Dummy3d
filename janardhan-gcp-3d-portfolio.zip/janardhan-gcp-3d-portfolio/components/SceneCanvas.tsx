 "use client";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, Line, Trail, Stars } from "@react-three/drei";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useSceneStore } from "@/lib/store";

function Dust() {
 const ref=useRef<THREE.Points>(null);
 const positions=useMemo(()=>{const a=new Float32Array(1800);for(let i=0;i<a.length;i++)a[i]=(Math.random()-.5)*(i%3===1?12:18);return a;},[]);
 useFrame((state,delta)=>{if(ref.current){ref.current.rotation.y+=delta*.018;ref.current.rotation.x=Math.sin(state.clock.elapsedTime*.12)*.08;}});
 return <points ref={ref}><bufferGeometry><bufferAttribute attach="attributes-position" args={[positions,3]}/></bufferGeometry><pointsMaterial color="#78aaff" size={.018} transparent opacity={.55} sizeAttenuation/></points>;
}
function DataTube({start,end,color,speed=1}:{start:[number,number,number];end:[number,number,number];color:string;speed?:number}) {
 const particle=useRef<THREE.Mesh>(null);
 const curve=useMemo(()=>new THREE.CatmullRomCurve3([new THREE.Vector3(...start),new THREE.Vector3(start[0]*.55,start[1]*.55,-.1),new THREE.Vector3(end[0]*.55,end[1]*.55,0),new THREE.Vector3(...end)]),[start,end]);
 useFrame((state)=>{if(particle.current)particle.current.position.copy(curve.getPoint((state.clock.elapsedTime*.22*speed)%1));});
 return <><mesh><tubeGeometry args={[curve,48,.018,8,false]}/><meshBasicMaterial color={color} transparent opacity={.28}/></mesh><Trail width={.11} length={5} color={color} attenuation={(t)=>t*t}><mesh ref={particle}><sphereGeometry args={[.045,12,12]}/><meshBasicMaterial color={color}/></mesh></Trail></>;
}
function Pipeline() {
 const group=useRef<THREE.Group>(null),cubes=useRef<THREE.Group>(null);
 const progress=useSceneStore(s=>s.progress);
 useFrame((state,delta)=>{const p=progress;if(group.current){const hero=p<.25,skills=p>=.25&&p<.48,projects=p>=.48&&p<.72,contact=p>=.88;const target=hero?0:skills?2.7:projects?-2.2:p<.88?1.8:-1.2;group.current.position.x=THREE.MathUtils.damp(group.current.position.x,target,2.1,delta);group.current.position.y=THREE.MathUtils.damp(group.current.position.y,hero?-.1:skills?.3:projects?-.5:.2,2,delta);group.current.scale.setScalar(THREE.MathUtils.damp(group.current.scale.x,hero?1:skills?.78:projects?.65:.8,2,delta));group.current.rotation.y+=delta*(hero?.08:.16);group.current.rotation.x=THREE.MathUtils.damp(group.current.rotation.x,contact?.3:0,2,delta);}if(cubes.current)cubes.current.rotation.y+=delta*.3;});
 const orbs=[["BQ",[-2.5,1.15,0],"#4285F4"],["DF",[-.85,1.8,.2],"#34A853"],["PS",[.95,1.55,0],"#8B5CF6"],["AF",[2.5,.9,0],"#4285F4"],["SQL",[-2,-.8,.3],"#34A853"],["PY",[-.5,-1.25,0],"#8B5CF6"],["TF",[1.4,-.9,.2],"#4285F4"],["DBT",[2.8,-.4,0],"#34A853"],["PS",[-3,.15,0],"#8B5CF6"],["GCS",[.1,.15,.4],"#4285F4"]] as [string,[number,number,number],string][];
 return <group ref={group}><ambientLight intensity={.55}/><pointLight position={[0,0,4]} intensity={8} color="#4285F4" distance={10}/><pointLight position={[2,2,-2]} intensity={5} color="#8B5CF6" distance={8}/>
 <mesh><cylinderGeometry args={[.68,.68,1.75,48,1,true]}/><meshPhysicalMaterial color="#0d1c36" emissive="#1258c5" emissiveIntensity={.75} metalness={.55} roughness={.22} transparent opacity={.83} side={THREE.DoubleSide}/></mesh>
 <mesh position={[0,.88,0]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[.65,.035,12,64]}/><meshBasicMaterial color="#7bb2ff"/></mesh><mesh position={[0,-.88,0]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[.65,.035,12,64]}/><meshBasicMaterial color="#8b5cf6"/></mesh>
 <DataTube start={[-3.4,1.25,0]} end={[-.45,.35,0]} color="#4285F4" speed={1.5}/><DataTube start={[-3.4,-.9,.2]} end={[-.5,-.35,0]} color="#34A853" speed={1.2}/><DataTube start={[3.4,1.05,0]} end={[.5,.3,0]} color="#8B5CF6" speed={1.7}/><DataTube start={[3.3,-1.1,.1]} end={[.5,-.4,0]} color="#4285F4" speed={1.35}/><DataTube start={[0,2.6,-.2]} end={[0,.8,0]} color="#34A853" speed={1.8}/>
 <group ref={cubes}>{[0,1,2,3].map(i=><Float key={i} speed={1.3+i*.2} rotationIntensity={.4} floatIntensity={.6}><mesh position={[Math.cos(i*Math.PI/2)*1.6,Math.sin(i*Math.PI/2)*1.25,.2]}><boxGeometry args={[.28,.28,.28]}/><meshStandardMaterial color={i%2?"#8B5CF6":"#4285F4"} emissive={i%2?"#8B5CF6":"#4285F4"} emissiveIntensity={1.4} metalness={.4} roughness={.2}/></mesh></Float>)}</group>
 {orbs.map(([name,pos,color],i)=><group key={i} position={pos}><mesh><sphereGeometry args={[.22,24,24]}/><meshPhysicalMaterial color={color} emissive={color} emissiveIntensity={.8} metalness={.25} roughness={.2} transparent opacity={.88}/></mesh><mesh><sphereGeometry args={[.29,16,16]}/><meshBasicMaterial color={color} wireframe transparent opacity={.18}/></mesh><Line points={[[0,0,0],[pos[0]*-.35,pos[1]*-.35,-.2]]} color={color} transparent opacity={.24} lineWidth={1}/></group>)}
 </group>;
}
function CameraRig(){const progress=useSceneStore(s=>s.progress);useFrame(({camera},delta)=>{const p=progress,x=p<.25?0:p<.48?.8:p<.72?-1:p<.88?1.2:0,y=p<.25?0:p<.48?.5:p<.72?-.2:p<.88?.3:0,z=p<.25?8.4:p<.48?9.5:p<.72?10:p<.88?9:8.4;camera.position.x=THREE.MathUtils.damp(camera.position.x,x,1.2,delta);camera.position.y=THREE.MathUtils.damp(camera.position.y,y,1.2,delta);camera.position.z=THREE.MathUtils.damp(camera.position.z,z,1.2,delta);camera.lookAt(0,0,0);});return null;}
export default function SceneCanvas(){return <div className="site-canvas" aria-hidden="true"><Canvas dpr={[1,1.6]} camera={{position:[0,0,8.4],fov:42}} gl={{antialias:true,alpha:true,powerPreference:"high-performance"}}><color attach="background" args={["#0A0A0B"]}/><fog attach="fog" args={["#0A0A0B",8,20]}/><Stars radius={70} depth={30} count={800} factor={2.2} saturation={.15} fade speed={.3}/><Dust/><Pipeline/><CameraRig/></Canvas></div>;}